# blueprints/payment/__init__.py
from flask import Blueprint
bp = Blueprint('payment', __name__)
from . import routes





